from distutils.core import setup

setup(name="felix", version="1.0", description="felix's first module", author="felix", py_modules=["TestPackage.sendmsg", "TestPackage.recvmsg"])
